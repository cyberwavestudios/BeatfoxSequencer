import { PitchKnob } from './pitch-knob';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { type TrackConfig } from '@shared/schema';

interface StepGridProps {
  tracks: TrackConfig[];
  currentStep: number;
  isPlaying: boolean;
  selectedLoop: string;
  availableLoops: Array<{ id: string; name: string; filename: string }>;
  onToggleStep: (trackId: string, stepIndex: number) => void;
  onTrackPitchChange: (trackId: string, pitch: number) => void;
  onLoopChange: (loopFilename: string) => void;
}

export function StepGrid({
  tracks,
  currentStep,
  isPlaying,
  selectedLoop,
  availableLoops,
  onToggleStep,
  onTrackPitchChange,
  onLoopChange,
}: StepGridProps) {
  return (
    <div className="space-y-2">
      {/* Grid Header - Step Numbers */}
      <div className="grid grid-cols-[200px_repeat(8,1fr)] gap-1 mb-2">
        <div className=""></div> {/* Track name column */}
        {Array.from({ length: 8 }, (_, i) => (
          <div key={i} className="text-center text-xs text-cyber-electric font-mono p-1">
            {String(i + 1).padStart(2, '0')}
          </div>
        ))}
      </div>

      {tracks.map((track) => (
        <div key={track.id} className="grid grid-cols-[200px_repeat(8,1fr)] gap-1 items-center p-2 track-label rounded">
          {/* Track Name and Controls */}
          <div className="flex items-center space-x-2">
            <span 
              className="font-orbitron text-sm font-bold"
              style={{ color: track.color }}
            >
              {track.name}
            </span>
            
            {/* Loop Selection */}
            {track.type === 'loop' && (
              <Select value={selectedLoop} onValueChange={onLoopChange}>
                <SelectTrigger className="w-32 bg-cyber-navy border-cyber-teal text-cyber-electric text-xs">
                  <SelectValue placeholder="Select loop" />
                </SelectTrigger>
                <SelectContent>
                  {availableLoops.map((loop) => (
                    <SelectItem key={loop.id} value={loop.filename}>
                      {loop.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            {/* Pitch Control */}
            {track.hasPitchControl && (
              <PitchKnob
                value={track.pitch || 0}
                onChange={(pitch) => onTrackPitchChange(track.id, pitch)}
                size={track.type === 'loop' ? 'md' : 'sm'}
              />
            )}
          </div>

          {/* Step Buttons or Loop Indicator */}
          {track.type === 'loop' ? (
            // Loop track shows continuous indicator instead of steps
            <div className="col-span-8 flex items-center">
              <div className="flex-1 h-8 rounded border-2 border-cyber-teal bg-gradient-to-r from-cyber-teal/20 to-cyber-purple/20 flex items-center justify-center">
                <div className="text-xs font-orbitron text-cyber-teal">
                  {selectedLoop ? 'CONTINUOUS LOOP' : 'NO LOOP SELECTED'}
                </div>
                {selectedLoop && isPlaying && (
                  <div className="ml-2 w-2 h-2 bg-cyber-teal rounded-full animate-pulse"></div>
                )}
              </div>
            </div>
          ) : (
            // Regular tracks show step buttons
            Array.from({ length: 8 }, (_, stepIndex) => {
              const isActive = track.steps[stepIndex];
              const isCurrentStep = isPlaying && currentStep === stepIndex;
              
              return (
                <button
                  key={stepIndex}
                  onClick={() => onToggleStep(track.id, stepIndex)}
                  className={`
                    step-button w-8 h-8 rounded border transition-all duration-200
                    ${isActive ? 'step-active' : 'bg-cyber-navy/50 hover:bg-opacity-20'}
                    ${isCurrentStep && isActive ? 'step-playing' : ''}
                  `}
                  style={{
                    borderColor: `${track.color}50`,
                    '--track-color': track.color,
                  } as React.CSSProperties}
                />
              );
            })
          )}
        </div>
      ))}
    </div>
  );
}
