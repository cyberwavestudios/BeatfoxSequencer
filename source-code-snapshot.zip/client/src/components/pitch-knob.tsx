import { useState, useCallback, useEffect } from 'react';

interface PitchKnobProps {
  value: number; // -12 to +12 semitones
  onChange: (value: number) => void;
  size?: 'sm' | 'md';
}

export function PitchKnob({ value, onChange, size = 'md' }: PitchKnobProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [startValue, setStartValue] = useState(0);

  const sizeClasses = size === 'sm' ? 'w-6 h-6' : 'w-8 h-8';

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    setStartY(e.clientY);
    setStartValue(value);
    e.preventDefault();
  }, [value]);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    setIsDragging(true);
    setStartY(e.touches[0].clientY);
    setStartValue(value);
    e.preventDefault();
  }, [value]);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging) return;

    const deltaY = startY - e.clientY; // Inverted for natural feel
    const sensitivity = 0.1;
    const newValue = Math.max(-12, Math.min(12, startValue + deltaY * sensitivity));
    onChange(Math.round(newValue));
  }, [isDragging, startY, startValue, onChange]);

  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (!isDragging) return;
    e.preventDefault();

    const deltaY = startY - e.touches[0].clientY;
    const sensitivity = 0.15; // Slightly higher sensitivity for touch
    const newValue = Math.max(-12, Math.min(12, startValue + deltaY * sensitivity));
    onChange(Math.round(newValue));
  }, [isDragging, startY, startValue, onChange]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false);
  }, []);

  // Attach global mouse and touch events
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.addEventListener('touchmove', handleTouchMove, { passive: false });
      document.addEventListener('touchend', handleTouchEnd);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [isDragging, handleMouseMove, handleMouseUp, handleTouchMove, handleTouchEnd]);

  // Calculate rotation angle (-144 to +144 degrees for -12 to +12 semitones)
  const rotation = (value / 12) * 144;

  return (
    <div className="flex flex-col items-center">
      <div 
        className={`control-knob ${sizeClasses} rounded-full cursor-pointer select-none touch-none`}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        style={{
          transform: `rotate(${rotation}deg)`,
        }}
      />
      <span className="text-xs text-cyber-electric mt-1 min-w-[2ch] text-center">
        {value > 0 ? '+' : ''}{value}
      </span>
    </div>
  );
}
