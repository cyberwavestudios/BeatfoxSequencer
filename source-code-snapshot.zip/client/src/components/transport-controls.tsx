import { Button } from '@/components/ui/button';

interface TransportControlsProps {
  isPlaying: boolean;
  bpm: number;
  currentStep: number;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
}

export function TransportControls({
  isPlaying,
  bpm,
  currentStep,
  onPlay,
  onPause,
  onStop,
}: TransportControlsProps) {
  return (
    <div className="flex items-center justify-between flex-wrap gap-4 p-4 track-label rounded-lg">
      {/* Transport Controls */}
      <div className="flex items-center space-x-3">
        {!isPlaying ? (
          <Button 
            onClick={onPlay}
            className="cyber-button px-4 py-2 font-orbitron text-cyber-lime hover:text-white rounded"
          >
            ▶ PLAY
          </Button>
        ) : (
          <Button 
            onClick={onPause}
            className="cyber-button px-4 py-2 font-orbitron text-cyber-hot-pink hover:text-white rounded"
          >
            ⏸ PAUSE
          </Button>
        )}
        <Button 
          onClick={onStop}
          className="cyber-button px-4 py-2 font-orbitron text-cyber-teal hover:text-white rounded"
        >
          ⏹ STOP
        </Button>
      </div>

      {/* BPM Display (Auto-synced) */}
      <div className="flex items-center space-x-3">
        <span className="text-cyber-electric text-sm font-orbitron">AUTO-SYNC BPM</span>
        <span className="text-cyber-teal font-mono text-lg">{bpm}</span>
      </div>

      {/* Current Step Indicator */}
      <div className="flex items-center space-x-2">
        <span className="text-cyber-electric text-sm">STEP</span>
        <span className="text-cyber-teal font-mono text-xl">
          {String(currentStep + 1).padStart(2, '0')}
        </span>
        <span className="text-cyber-electric">/8</span>
      </div>
    </div>
  );
}
