import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Pause } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import * as Tone from 'tone';
import { type Loop } from '@shared/schema';

interface LoopSelectorProps {
  loops: Loop[];
  onLoopSelect: (loop: Loop) => void;
  onBack: () => void;
}

export function LoopSelector({ loops, onLoopSelect, onBack }: LoopSelectorProps) {
  const [previewPlaying, setPreviewPlaying] = useState<string | null>(null);
  const previewPlayers = useRef<Map<string, Tone.Player>>(new Map());

  useEffect(() => {
    return () => {
      // Cleanup all preview players on unmount
      previewPlayers.current.forEach(player => {
        player.dispose();
      });
      previewPlayers.current.clear();
    };
  }, []);

  const handlePreviewToggle = async (loop: Loop, event: React.MouseEvent) => {
    event.stopPropagation(); // Prevent card selection

    try {
      // Ensure audio context is started and running
      await Tone.start();
      if (Tone.context.state !== 'running') {
        await Tone.context.resume();
      }

      if (previewPlaying === loop.id) {
        // Stop current preview
        const player = previewPlayers.current.get(loop.id);
        if (player) {
          try {
            player.stop();
          } catch (error) {
            console.error('Failed to stop preview:', error);
          }
        }
        setPreviewPlaying(null);
        return;
      }

      // Stop any currently playing preview
      if (previewPlaying) {
        const currentPlayer = previewPlayers.current.get(previewPlaying);
        if (currentPlayer) {
          try {
            currentPlayer.stop();
          } catch (error) {
            console.error('Failed to stop current preview:', error);
          }
        }
      }

      setPreviewPlaying(loop.id);

      // Start new preview
      let player = previewPlayers.current.get(loop.id);
      if (!player) {
        player = new Tone.Player().toDestination();
        previewPlayers.current.set(loop.id, player);
        
        // Configure player first for faster response
        player.loop = true;
        player.volume.value = -6;
        
        // Load and start asynchronously for immediate UI feedback
        const originalUrl = `/audio/loops/${loop.filename}`;
        const encodedUrl = originalUrl.replace('#', '%23');
        
        // Use await to properly handle errors
        try {
          await player.load(encodedUrl);
          console.log('Preview loaded successfully:', loop.filename);
          if (previewPlaying === loop.id && player) {
            await player.start();
          }
        } catch (error) {
          console.error('Failed to load preview:', loop.filename, error);
          setPreviewPlaying(null);
        }
      } else if (player.loaded) {
        // Immediate start for already loaded players
        try {
          await player.start();
        } catch (error) {
          console.error('Failed to start preview:', error);
          setPreviewPlaying(null);
        }
      } else {
        // Player not loaded yet, wait briefly then try again
        setTimeout(async () => {
          if (player && player.loaded && previewPlaying === loop.id) {
            try {
              await player.start();
            } catch (error) {
              console.error('Failed to start delayed preview:', error);
              setPreviewPlaying(null);
            }
          } else {
            setPreviewPlaying(null);
          }
        }, 100);
      }
    } catch (error) {
      console.error('Failed to load preview:', loop.filename, error);
      setPreviewPlaying(null);
    }
  };
  return (
    <div className="min-h-dvh p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-orbitron font-bold text-cyber-teal">SELECT A LOOP TO BEGIN</h1>
          <Button 
            onClick={onBack}
            className="cyber-button px-4 py-2 text-cyber-electric hover:text-white rounded"
          >
            ← BACK
          </Button>
        </div>

        {/* Beatfox Animation */}
        <div className="beatfox-glow mb-8 p-6 border-2 border-cyber-teal rounded-lg bg-gradient-to-br from-cyber-purple/30 to-cyber-navy/30 text-center">
          <div className="flex items-center justify-center space-x-4 mb-4">
            <div className="w-16 h-16 rounded-lg overflow-hidden border border-cyber-teal bg-gradient-to-br from-cyber-orange/20 to-cyber-purple/20 flex items-center justify-center">
              <img 
                src="/beatfox-logo.png" 
                alt="Beatfox Logo"
                className="w-12 h-12 object-contain animate-pulse hover:animate-bounce transition-all duration-300"
                onError={(e) => {
                  console.error('Failed to load Beatfox logo from /beatfox-logo.png');
                  // Try fallback path
                  e.currentTarget.src = '/attached_assets/D41CF353-BE7D-45E5-A42B-274E8AC05BA8_1755467853570.PNG';
                }}
                onLoad={() => console.log('Beatfox logo loaded successfully')}
              />
            </div>
            <div className="text-4xl font-orbitron font-black text-cyber-teal">BEATFOX</div>
          </div>
          <div className="text-lg font-orbitron text-cyber-electric">Choose your foundation loop</div>
        </div>

        {/* Loop Selection Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loops.map((loop) => (
            <Card key={loop.id} className="track-label border-cyber-teal/30 bg-cyber-navy/20 hover:bg-cyber-navy/40 transition-all duration-300">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-orbitron text-cyber-teal font-bold">{loop.name}</span>
                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="p-2 h-8 w-8 text-cyber-electric hover:text-cyber-teal hover:bg-cyber-navy/50"
                      onClick={(e) => handlePreviewToggle(loop, e)}
                    >
                      {previewPlaying === loop.id ? <Pause size={16} /> : <Play size={16} />}
                    </Button>
                    <div className="flex space-x-1">
                      <span className="text-xs text-cyber-electric px-2 py-1 bg-cyber-navy rounded">
                        {loop.bpm} BPM
                      </span>
                      {loop.key && (
                        <span className="text-xs text-cyber-electric px-2 py-1 bg-cyber-purple/30 rounded">
                          {loop.key}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                {loop.mood && (
                  <div className="text-sm text-gray-400 mb-3">{loop.mood}</div>
                )}
                <div className="text-center">
                  <Button 
                    className="cyber-button w-full py-2 text-cyber-teal hover:text-white rounded text-sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onLoopSelect(loop);
                    }}
                  >
                    SELECT LOOP
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {(!loops || loops.length === 0) && (
          <div className="text-center py-12">
            <div className="text-cyber-electric font-orbitron text-xl mb-4">
              No loops available
            </div>
            <p className="text-gray-400">
              Audio assets will be available once they are uploaded to the server.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}