import * as Tone from 'tone';

export interface AudioTrack {
  id: string;
  name: string;
  type: 'loop' | 'oneshot';
  player?: Tone.Player;
  pitchShift?: Tone.PitchShift;
  steps: boolean[];
  pitch: number;
  muted: boolean;
  volume: number;
  isLooping?: boolean;
  currentPlayer?: Tone.Player; // Track currently playing instance for note-off
  trimmedBuffer?: Tone.ToneAudioBuffer; // Store trimmed audio for perfect loops
  audioUrl?: string; // Store original URL for identification
}

export class AudioEngine {
  private transport: typeof Tone.Transport;
  private tracks: Map<string, AudioTrack> = new Map();
  private sequence?: Tone.Sequence;
  private currentStep: number = 0;
  private isInitialized: boolean = false;
  private sequencerLoopCount: number = 0; // Count completed 8-step loops
  
  constructor() {
    this.transport = Tone.Transport;
    this.transport.bpm.value = 90;
  }

  async initialize() {
    if (this.isInitialized) return;
    
    try {
      await Tone.start();
      // Ensure audio context is in running state
      if (Tone.context.state !== 'running') {
        await Tone.context.resume();
      }
      console.log('Audio engine initialized successfully');
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize audio engine:', error);
      throw error;
    }
  }

  async loadTrack(config: {
    id: string;
    name: string;
    type: 'loop' | 'oneshot';
    audioUrl?: string;
    hasPitchControl?: boolean;
  }) {
    const { id, name, type, audioUrl, hasPitchControl } = config;
    
    const track: AudioTrack = {
      id,
      name,
      type,
      steps: new Array(8).fill(false),
      pitch: 0,
      muted: false,
      volume: type === 'loop' ? 1.0 : 0.4, // Loops louder, one-shots quieter
      audioUrl, // Store the URL for identification
    };

    if (audioUrl) {
      // Create player for audio file with volume control
      if (type === 'loop') {
        // For loops, use looping player with pitch shift and volume control
        const gainNode = new Tone.Gain(track.volume).toDestination();
        track.player = new Tone.Player().connect(gainNode);
        
        // Add pitch shift if needed
        if (hasPitchControl) {
          track.pitchShift = new Tone.PitchShift(0).connect(gainNode);
          track.player.disconnect();
          track.player.connect(track.pitchShift);
        }
        
        try {
          const encodedUrl = audioUrl.replace('#', '%23');
          console.log('Fast-loading loop:', audioUrl);
          
          // If there's already a loop loaded, stop and dispose it first
          if (this.tracks.has('loop')) {
            const existingLoop = this.tracks.get('loop');
            if (existingLoop && existingLoop.player) {
              existingLoop.player.stop();
              existingLoop.player.dispose();
              existingLoop.isLooping = false;
            }
          }
          
          // Fast load without complex processing
          await track.player.load(encodedUrl);
          track.player.loop = true;
          track.player.volume.value = -6;
          
          console.log('Loop loaded successfully:', audioUrl);
        } catch (error) {
          console.error('Failed to load loop:', audioUrl, error);
          throw error;
        }
        
        // Store reference for independent control
        track.isLooping = false;
      } else {
        // For one-shots, use player with volume control
        const gainNode = new Tone.Gain(track.volume).toDestination();
        track.player = new Tone.Player().connect(gainNode);
        
        // Add pitch shift if required for one-shots  
        if (hasPitchControl) {
          track.pitchShift = new Tone.PitchShift(0).connect(gainNode);
          track.player.disconnect();
          track.player.connect(track.pitchShift);
        }
        
        try {
          const encodedUrl = encodeURI(audioUrl);
          await track.player.load(encodedUrl);
          console.log('One-shot loaded successfully:', audioUrl);
        } catch (error) {
          console.error('Failed to load one-shot:', audioUrl, error);
          // Don't throw for one-shots, just log the error
        }
      }
    }

    this.tracks.set(id, track);
  }

  setTrackPitch(trackId: string, pitch: number) {
    const track = this.tracks.get(trackId);
    if (track && track.pitchShift) {
      track.pitch = Math.max(-12, Math.min(12, pitch));
      track.pitchShift.pitch = track.pitch;
    }
  }

  toggleStep(trackId: string, stepIndex: number) {
    const track = this.tracks.get(trackId);
    if (track) {
      track.steps[stepIndex] = !track.steps[stepIndex];
    }
  }

  getTrackSteps(trackId: string): boolean[] {
    const track = this.tracks.get(trackId);
    return track ? track.steps : new Array(8).fill(false);
  }

  setupSequence(onStep?: (step: number) => void) {
    this.sequence = new Tone.Sequence((time, step) => {
      this.currentStep = step;
      
      // Track sequencer loop completion (every 8 steps)
      if (step === 0 && this.sequencerLoopCount > 0) {
        // Check for custom loop restarts at specific intervals
        this.tracks.forEach((track) => {
          if (track.type === 'loop' && track.player && track.isLooping) {
            const currentLoopUrl = track.audioUrl || '';
            let shouldRestart = false;
            
            if (currentLoopUrl.includes('140_DystopiaSynths_Em.wav') && this.sequencerLoopCount > 32 && (this.sequencerLoopCount - 1) % 32 === 0) {
              // Dystopia Synths: restart AFTER 32 complete loops (at loop 33, 65, 97, etc.)
              shouldRestart = true;
              console.log(`Restarting Dystopia Synths at sequencer loop ${this.sequencerLoopCount}`);
            } else if (currentLoopUrl.includes('155_CyberKeys_Am.wav') && this.sequencerLoopCount > 16 && (this.sequencerLoopCount - 1) % 16 === 0) {
              // Cyber Keys: restart AFTER 16 complete loops (at loop 17, 33, 49, etc.)
              shouldRestart = true;
              console.log(`Restarting Cyber Keys at sequencer loop ${this.sequencerLoopCount}`);
            } else if (currentLoopUrl.includes('134_IMightBeJohnMayerIDK_F#m.wav') && this.sequencerLoopCount > 16 && (this.sequencerLoopCount - 1) % 16 === 0) {
              // John Mayer: restart AFTER 16 complete loops (at loop 17, 33, 49, etc.)
              shouldRestart = true;
              console.log(`Restarting John Mayer at sequencer loop ${this.sequencerLoopCount}`);
            } else if (currentLoopUrl.includes('171_EDM_Synth_G#m.wav') && this.sequencerLoopCount > 16 && (this.sequencerLoopCount - 1) % 16 === 0) {
              // EDM Synth: restart AFTER 16 complete loops (at loop 17, 33, 49, etc.)
              shouldRestart = true;
              console.log(`Restarting EDM Synth at sequencer loop ${this.sequencerLoopCount}`);
            }
            
            if (shouldRestart) {
              // Stop the current loop and restart immediately at the exact timing
              track.player.stop();
              track.isLooping = false;
              
              // Restart at the exact scheduled time (step 0 = "1" beat)
              track.player.start(time);
              track.isLooping = true;
              
              console.log(`Loop restarted: ${currentLoopUrl} at step ${step}, loop count ${this.sequencerLoopCount}`);
            }
          }
        });
      }
      
      // Increment loop counter at the end of each 8-step cycle
      if (step === 7) {
        this.sequencerLoopCount++;
      }
      
      // Trigger tracks that have this step active
      this.tracks.forEach((track) => {
        if (track.type === 'loop') {
          // Loop tracks are handled independently but synchronized
          return;
        }
        
        if (track.steps[step] && track.player && !track.muted && track.player.loaded) {
          // Stop any currently playing instance (note-off behavior)
          if (track.currentPlayer && track.currentPlayer.state === 'started') {
            track.currentPlayer.stop();
            track.currentPlayer.dispose();
          }
          
          // Create a new player instance for non-overlapping playback with volume control
          const triggerPlayer = new Tone.Player(track.player.buffer);
          const gainNode = new Tone.Gain(track.volume).toDestination();
          triggerPlayer.connect(gainNode);
          
          // Connect to pitch shift if available
          if (track.pitchShift) {
            triggerPlayer.disconnect();
            triggerPlayer.connect(track.pitchShift);
          }
          
          // Store reference for note-off behavior
          track.currentPlayer = triggerPlayer;
          
          // Start at the exact scheduled time for tight synchronization
          triggerPlayer.start(time);
          
          // Dispose after playback to prevent memory leaks
          triggerPlayer.onstop = () => {
            if (track.currentPlayer === triggerPlayer) {
              track.currentPlayer = undefined;
            }
            triggerPlayer.dispose();
          };
        }
      });

      // Call callback for visual feedback
      if (onStep) {
        Tone.Draw.schedule(() => onStep(step), time);
      }
    }, Array.from({ length: 8 }, (_, i) => i), "8n");

    // Start sequence at position 0 for proper alignment
    this.sequence.start(0);
  }

  async play() {
    if (!this.isInitialized) {
      await this.initialize();
    }
    
    // Ensure audio context is running
    if (Tone.context.state !== 'running') {
      await Tone.context.resume();
    }
    
    console.log('Play method called, checking tracks...');
    this.tracks.forEach(track => {
      console.log(`Track ${track.id}: type=${track.type}, hasPlayer=${!!track.player}, loaded=${track.player?.loaded}, muted=${track.muted}, isLooping=${track.isLooping}`);
    });
    
    // Start transport and ensure loops start in perfect sync
    this.transport.start();
    
    // Calculate the exact start time to ensure perfect synchronization
    // Loops should start at the beginning of the next measure, exactly when the sequencer starts
    const nextMeasureStart = this.transport.nextSubdivision("1m");
    
    this.tracks.forEach(track => {
      if (track.type === 'loop' && track.player && !track.muted && !track.isLooping) {
        if (track.player.loaded) {
          console.log('Starting loop player for track:', track.id, 'at measure start:', nextMeasureStart);
          // Use the exact same timing as the sequencer to ensure perfect sync
          track.player.start(nextMeasureStart);
          track.isLooping = true;
        } else {
          console.warn('Loop player not loaded yet:', track.id);
        }
      }
    });
  }

  pause() {
    // Pause all looping players
    this.tracks.forEach(track => {
      if (track.type === 'loop' && track.player && track.isLooping) {
        track.player.stop();
        track.isLooping = false;
      }
    });
    
    this.transport.pause();
  }

  stop() {
    // Stop transport but don't cancel all events (this was breaking the sequence)
    this.transport.stop();
    
    // Stop all looping players and ensure they're completely stopped
    this.tracks.forEach(track => {
      if (track.type === 'loop' && track.player) {
        if (track.isLooping || track.player.state === 'started') {
          track.player.stop();
        }
        track.isLooping = false;
      }
      
      // Also stop any current one-shot players
      if (track.currentPlayer && track.currentPlayer.state === 'started') {
        track.currentPlayer.stop();
        track.currentPlayer.dispose();
        track.currentPlayer = undefined;
      }
    });
    
    // Reset sequence position
    this.currentStep = 0;
    this.sequencerLoopCount = 0;
    
    // Reset transport position for clean restart
    this.transport.position = 0;
  }

  setBPM(bpm: number) {
    this.transport.bpm.value = Math.max(60, Math.min(180, bpm));
  }

  getBPM(): number {
    return this.transport.bpm.value;
  }

  getCurrentStep(): number {
    return this.currentStep;
  }

  getProgress(): number {
    return (this.currentStep + 1) / 8;
  }

  isPlaying(): boolean {
    return this.transport.state === 'started';
  }

  setTrackVolume(trackId: string, volume: number) {
    const track = this.tracks.get(trackId);
    if (track && track.player) {
      track.volume = Math.max(0, Math.min(1, volume));
      track.player.volume.value = Tone.gainToDb(track.volume);
    }
  }

  muteTrack(trackId: string, muted: boolean) {
    const track = this.tracks.get(trackId);
    if (track) {
      track.muted = muted;
    }
  }

  // Audio trimming function - SMART START TRIM: Only remove silence at start, preserve full musical content
  async trimAudioStart(track: AudioTrack) {
    if (!track.player || !track.player.loaded) return;
    
    const buffer = track.player.buffer;
    if (!buffer) return;
    
    const audioData = buffer.toArray() as Float32Array[];
    if (!audioData || audioData.length === 0) return;
    
    const sampleRate = buffer.sampleRate;
    const channelData = audioData[0];
    
    // Find first transient (audio above threshold) to remove leading silence only
    let threshold = 0.0005; // 0.05% amplitude threshold - more sensitive
    let bufferTime = 0.005; // 5ms buffer before first audio
    
    // Special handling for loops that need more aggressive trimming
    const currentLoopUrl = track.audioUrl || '';
    if (currentLoopUrl.includes('134_IMightBeJohnMayerIDK_F#m.wav')) {
      // John Mayer loop: more sensitive detection, smaller buffer
      threshold = 0.0002;
      bufferTime = 0.002;
    } else if (currentLoopUrl.includes('171_EDM_Synth_G#m.wav')) {
      // EDM Synth loop: more sensitive detection, smaller buffer  
      threshold = 0.0002;
      bufferTime = 0.002;
    }
    
    let startSample = 0;
    for (let i = 0; i < channelData.length; i++) {
      if (Math.abs(channelData[i]) > threshold) {
        // Keep buffer before first audio to preserve attack
        startSample = Math.max(0, i - Math.floor(sampleRate * bufferTime));
        break;
      }
    }
    
    // Trim any detectable silence at the start (even small amounts)
    const minSilenceToTrim = currentLoopUrl.includes('134_IMightBeJohnMayerIDK_F#m.wav') || 
                            currentLoopUrl.includes('171_EDM_Synth_G#m.wav') ? 
                            sampleRate * 0.005 : // 5ms for special loops
                            sampleRate * 0.01;   // 10ms for others
    
    if (startSample > minSilenceToTrim) {
      // Create trimmed buffer - remove start silence, keep full musical content
      const trimmedLength = channelData.length - startSample;
      const trimmedData: Float32Array[] = [];
      
      for (let channel = 0; channel < audioData.length; channel++) {
        const trimmed = audioData[channel].slice(startSample);
        trimmedData.push(trimmed);
      }
      
      // Apply start-only trimmed buffer
      track.trimmedBuffer = new Tone.ToneAudioBuffer().fromArray(trimmedData);
      track.player.buffer = track.trimmedBuffer;
      
      console.log(`Start-trimmed: removed ${startSample/sampleRate}s silence, kept full musical content (${trimmedLength/sampleRate}s)`);
    } else {
      console.log(`No start trimming needed - loop already starts clean`);
    }
    
    // Log final timing for sync verification
    const finalDuration = track.player.buffer.duration;
    
    if (track.type === 'loop') {
      const bpm = this.transport.bpm.value;
      const samplesPerMeasure = (60 / bpm) * sampleRate * 4;
      const measures = (finalDuration * sampleRate) / samplesPerMeasure;
      
      // Custom restart measures for specific loops based on stored audioUrl
      let nextMultipleOf4;
      const currentLoopUrl = track.audioUrl || '';
      
      if (currentLoopUrl.includes('140_DystopiaSynths_Em.wav')) { // Dystopia Synths
        nextMultipleOf4 = 32;
      } else if (currentLoopUrl.includes('155_CyberKeys_Am.wav')) { // Cyber Keys  
        nextMultipleOf4 = 16;
      } else if (currentLoopUrl.includes('134_IMightBeJohnMayerIDK_F#m.wav')) { // John Mayer
        nextMultipleOf4 = 16;
      } else if (currentLoopUrl.includes('171_EDM_Synth_G#m.wav')) { // EDM Synth
        nextMultipleOf4 = 16;
      } else {
        nextMultipleOf4 = Math.ceil(measures / 4) * 4;
      }
      
      console.log(`Loop: ${finalDuration}s = ${measures.toFixed(2)} measures → will restart at measure ${nextMultipleOf4}`);
    } else {
      console.log(`One-shot: ${finalDuration}s (${track.id})`);
    }
  }

  // Export current sequence as audio file - mixes loop and sequencer tracks
  async exportSequence(): Promise<Blob> {
    if (!this.isInitialized) {
      throw new Error('Audio engine not initialized');
    }

    const loopTrack = this.tracks.get('loop');
    if (!loopTrack || !loopTrack.player || !loopTrack.player.loaded) {
      throw new Error('No loop track loaded');
    }

    // Get the loop duration to determine export length
    const loopDuration = loopTrack.player.buffer!.duration;
    const sampleRate = 44100;
    const channels = 2;
    const totalSamples = Math.ceil(loopDuration * sampleRate);
    
    // Create output buffer for stereo mix
    const outputBuffer = new AudioBuffer({
      numberOfChannels: channels,
      length: totalSamples,
      sampleRate: sampleRate
    });
    
    const leftChannel = outputBuffer.getChannelData(0);
    const rightChannel = outputBuffer.getChannelData(1);
    
    // Add the loop track audio
    const loopBuffer = loopTrack.player.buffer!.toArray() as Float32Array[];
    const loopLeft = loopBuffer[0] || loopBuffer;
    const loopRight = loopBuffer[1] || loopBuffer[0] || loopBuffer;
    
    // Mix in the loop (with volume adjustment)
    for (let i = 0; i < Math.min(totalSamples, loopLeft.length); i++) {
      leftChannel[i] += loopLeft[i] * loopTrack.volume;
      rightChannel[i] += loopRight[i] * loopTrack.volume;
    }
    
    // Calculate sequencer timing
    const bpm = this.transport.bpm.value;
    const stepDuration = 60 / bpm / 2; // 8th notes
    const loopCycles = Math.ceil(loopDuration / (stepDuration * 8));
    
    // Mix in sequencer tracks (one-shots repeated in a loop pattern)
    this.tracks.forEach((track, trackId) => {
      if (track.type === 'oneshot' && track.player && track.player.loaded && !track.muted) {
        const trackBuffer = track.player.buffer!.toArray() as Float32Array[];
        const trackLeft = trackBuffer[0] || trackBuffer;
        const trackRight = trackBuffer[1] || trackBuffer[0] || trackBuffer;
        
        // Apply pitch shifting approximation if needed
        let processedLeft = trackLeft;
        let processedRight = trackRight;
        
        if (track.pitch !== 0) {
          const pitchRatio = Math.pow(2, track.pitch / 12);
          const newLength = Math.floor(trackLeft.length / pitchRatio);
          processedLeft = new Float32Array(newLength);
          processedRight = new Float32Array(newLength);
          
          for (let i = 0; i < newLength; i++) {
            const sourceIndex = Math.floor(i * pitchRatio);
            if (sourceIndex < trackLeft.length) {
              processedLeft[i] = trackLeft[sourceIndex];
              processedRight[i] = trackRight[sourceIndex];
            }
          }
        }
        
        // Place the one-shot samples at their sequencer positions throughout the loop
        for (let cycle = 0; cycle < loopCycles; cycle++) {
          for (let step = 0; step < 8; step++) {
            if (track.steps[step]) {
              const startSample = Math.floor((cycle * 8 + step) * stepDuration * sampleRate);
              
              // Mix in the sample
              for (let i = 0; i < processedLeft.length && (startSample + i) < totalSamples; i++) {
                leftChannel[startSample + i] += processedLeft[i] * track.volume;
                rightChannel[startSample + i] += processedRight[i] * track.volume;
              }
            }
          }
        }
      }
    });
    
    // Normalize audio to prevent clipping
    let maxSample = 0;
    for (let i = 0; i < totalSamples; i++) {
      maxSample = Math.max(maxSample, Math.abs(leftChannel[i]), Math.abs(rightChannel[i]));
    }
    
    if (maxSample > 0.95) {
      const normalizeRatio = 0.95 / maxSample;
      for (let i = 0; i < totalSamples; i++) {
        leftChannel[i] *= normalizeRatio;
        rightChannel[i] *= normalizeRatio;
      }
    }
    
    // Convert to WAV format
    return this.audioBufferToWav(outputBuffer);
  }
  
  private audioBufferToWav(buffer: AudioBuffer): Blob {
    const length = buffer.length;
    const sampleRate = buffer.sampleRate;
    const channels = buffer.numberOfChannels;
    const arrayBuffer = new ArrayBuffer(44 + length * channels * 2);
    const view = new DataView(arrayBuffer);
    
    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };
    
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * channels * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, channels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * channels * 2, true);
    view.setUint16(32, channels * 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * channels * 2, true);
    
    // Convert audio data
    let offset = 44;
    for (let i = 0; i < length; i++) {
      for (let channel = 0; channel < channels; channel++) {
        const sample = Math.max(-1, Math.min(1, buffer.getChannelData(channel)[i]));
        view.setInt16(offset, sample * 0x7FFF, true);
        offset += 2;
      }
    }
    
    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  dispose() {
    this.sequence?.dispose();
    this.tracks.forEach(track => {
      track.player?.dispose();
      track.pitchShift?.dispose();
      track.trimmedBuffer?.dispose();
    });
    this.tracks.clear();
  }
}

export const audioEngine = new AudioEngine();
