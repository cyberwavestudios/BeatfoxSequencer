import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useDeviceOrientation } from "@/hooks/use-device-orientation";
import { useEffect } from "react";
import TitleScreen from "@/pages/title-screen";
import DownloadScreen from "@/pages/download-screen";
import Sequencer from "@/pages/sequencer";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={TitleScreen} />
      <Route path="/downloads" component={DownloadScreen} />
      <Route path="/sequencer" component={Sequencer} />
      <Route component={NotFound} />
    </Switch>
  );
}

function OrientationManager({ children }: { children: React.ReactNode }) {
  const orientation = useDeviceOrientation();

  useEffect(() => {
    if (orientation === 'landscape') {
      document.body.classList.add('device-landscape');
      document.body.classList.remove('device-portrait');
    } else {
      document.body.classList.add('device-portrait');
      document.body.classList.remove('device-landscape');
    }
    return () => {
      document.body.classList.remove('device-landscape', 'device-portrait');
    };
  }, [orientation]);

  return <>{children}</>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <OrientationManager>
          <div className="min-h-dvh bg-gradient-to-br from-cyber-dark via-cyber-navy to-cyber-purple text-white relative">
            {/* Background Stars */}
            <div className="fixed inset-0 z-0 stars-bg opacity-30 pointer-events-none"></div>
            
            {/* Main Content */}
            <div className="relative z-10">
              <Router />
            </div>
          </div>
        </OrientationManager>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
