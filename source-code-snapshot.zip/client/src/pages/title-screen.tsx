import { useLocation } from 'wouter';

export default function TitleScreen() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center p-4">
      {/* Beatfox Logo/Animation */}
      <div className="beatfox-glow mb-8 p-8 border-2 border-cyber-teal rounded-lg bg-gradient-to-br from-cyber-purple/30 to-cyber-navy/30">
        <div className="text-center">
          <div className="text-6xl font-orbitron font-black text-cyber-teal mb-2">BEATFOX</div>
          <div className="text-xl font-orbitron text-cyber-electric">SEQUENCER</div>
          <div className="w-16 h-1 bg-gradient-to-r from-cyber-teal to-cyber-neon-purple mx-auto mt-4"></div>
        </div>
      </div>

      {/* Title Screen Buttons */}
      <div className="space-y-4 text-center">
        <button 
          onClick={() => setLocation('/sequencer')}
          className="cyber-button px-8 py-4 text-xl font-orbitron font-bold text-cyber-teal hover:text-white rounded-lg block w-full max-w-xs"
        >
          START SEQUENCER
        </button>
        <button 
          onClick={() => setLocation('/downloads')}
          className="cyber-button px-8 py-4 text-xl font-orbitron font-bold text-cyber-neon-purple hover:text-white rounded-lg block w-full max-w-xs"
        >
          DOWNLOAD LOOPS
        </button>
      </div>
    </div>
  );
}
