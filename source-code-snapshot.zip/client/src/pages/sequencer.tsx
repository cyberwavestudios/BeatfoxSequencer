import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useSequencer } from '@/hooks/use-sequencer';
import { TransportControls } from '@/components/transport-controls';
import { StepGrid } from '@/components/step-grid';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ArrowLeft } from 'lucide-react';
import { type Loop } from '@shared/schema';
import { useEffect } from 'react';
import beatfoxLogoPath from "@assets/D41CF353-BE7D-45E5-A42B-274E8AC05BA8_1755469228838.png";

export default function Sequencer() {
  const [, setLocation] = useLocation();
  const {
    isPlaying,
    currentStep,
    bpm,
    tracks,
    selectedLoop,
    selectedLoopData,
    hasSelectedLoop,
    play,
    pause,
    stop,
    toggleStep,
    setTrackPitch,
    loadLoop,
    exportSequence,
    progress,
    isLoading,
  } = useSequencer();

  const { data: loops = [] } = useQuery<Loop[]>({
    queryKey: ['/api/loops'],
  });

  const handleLoopChange = async (filename: string) => {
    const loop = loops.find(l => l.filename === filename);
    if (loop) {
      await loadLoop(filename, loop);
    }
  };

  useEffect(() => {
    document.body.classList.add('sequencer-landscape');
    return () => {
      document.body.classList.remove('sequencer-landscape');
    };
  }, []);

  return (
    <div className="min-h-dvh bg-gradient-to-br from-cyber-dark via-cyber-navy to-cyber-purple">
      {/* Beatfox Header with New Logo and Glitch Animation */}
      <div className="p-4 text-center border-b border-cyber-teal/30 bg-cyber-dark/50">
        <div className="flex items-center justify-between max-w-6xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => setLocation('/')} 
            className="p-2 text-cyber-teal hover:text-white transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          
          {/* Beatfox Logo with Glitch Animation */}
          <div className="flex items-center space-x-4">
            <div className="beatfox-logo-glow w-16 h-16 rounded-lg overflow-hidden border border-cyber-orange bg-gradient-to-br from-cyber-orange/20 to-cyber-purple/20 flex items-center justify-center">
              <img 
                src={beatfoxLogoPath} 
                alt="Beatfox Logo"
                className="w-12 h-12 object-contain animate-pulse"
              />
            </div>
            <div className="text-center">
              <div className="text-2xl font-orbitron font-black text-cyber-orange beatfox-glitch">BEATFOX</div>
              <div className="text-sm font-orbitron text-cyber-teal">SEQUENCER</div>
            </div>
          </div>
          
          {/* Loop Selector Dropdown */}
          <div className="w-64">
            <Label className="text-cyber-teal text-sm mb-2 block">SELECT LOOP</Label>
            <Select value={selectedLoop} onValueChange={handleLoopChange}>
              <SelectTrigger className="cyber-input">
                <SelectValue placeholder="Select a loop..." />
              </SelectTrigger>
              <SelectContent>
                {loops.map((loop) => (
                  <SelectItem key={loop.filename} value={loop.filename}>
                    {loop.name} - {loop.bpm} BPM - {loop.key}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Guidance Message */}
        <div className="mt-4 text-cyber-electric text-sm font-orbitron">
          💡 Change key and tempo by changing the selected loop!
        </div>
      </div>

      {/* Main Sequencer Content */}
      <div className={`p-4 max-w-6xl mx-auto space-y-6 transition-all duration-300 ${isLoading ? 'opacity-30 pointer-events-none' : 'opacity-100'}`}>
        {/* Loop Info Display */}
        <div className="p-4 track-label rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-cyber-teal font-orbitron font-bold">
                {selectedLoopData?.name || "Loading..."}
              </div>
              <div className="text-sm text-cyber-electric">
                {selectedLoopData?.bpm} BPM • Key: {selectedLoopData?.key || "Unknown"} • Auto-synced
              </div>
            </div>
            {isLoading && (
              <div className="flex items-center gap-3 bg-cyber-navy px-4 py-2 rounded-lg border-2 border-cyber-orange shadow-lg shadow-cyber-orange/30 relative z-10">
                <div className="w-6 h-6 border-3 border-cyber-teal/30 border-t-cyber-orange rounded-full animate-spin"></div>
                <span className="text-cyber-orange font-orbitron text-sm font-bold">LOADING LOOP...</span>
              </div>
            )}
          </div>
        </div>

        {/* Transport Controls */}
        <TransportControls
          isPlaying={isPlaying}
          bpm={bpm}
          currentStep={currentStep}
          onPlay={play}
          onPause={pause}
          onStop={stop}
        />

        {/* Export Section */}
        <div className="p-4 track-label rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-cyber-teal font-orbitron font-bold mb-1">Export Sequence</div>
              <div className="text-sm text-cyber-electric">Download your beat as an audio file (loop + sequencer mix)</div>
            </div>
            <button
              onClick={exportSequence}
              disabled={!hasSelectedLoop}
              className="px-4 py-2 bg-cyber-orange hover:bg-cyber-orange/80 disabled:bg-gray-600 text-white font-orbitron text-sm rounded-lg transition-colors"
            >
              Export WAV
            </button>
          </div>
        </div>

        {/* Step Sequencer Grid */}
        <StepGrid
          tracks={tracks}
          currentStep={currentStep}
          isPlaying={isPlaying}
          selectedLoop={selectedLoop}
          availableLoops={loops}
          onToggleStep={toggleStep}
          onTrackPitchChange={setTrackPitch}
          onLoopChange={handleLoopChange}
        />
      </div>
      
    </div>
  );
}