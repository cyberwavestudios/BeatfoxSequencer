import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { type Loop } from '@shared/schema';

export default function DownloadScreen() {
  const [, setLocation] = useLocation();

  const { data: loops, isLoading, error } = useQuery<Loop[]>({
    queryKey: ['/api/loops'],
  });

  const handleDownload = async (loop: Loop) => {
    try {
      const response = await fetch(`/api/loops/${loop.id}/download`);
      if (!response.ok) throw new Error('Download failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = loop.filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download failed:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-dvh p-4 flex items-center justify-center">
        <div className="text-cyber-teal font-orbitron text-xl">Loading loops...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-dvh p-4 flex items-center justify-center">
        <div className="text-cyber-hot-pink font-orbitron text-xl">
          Failed to load loops. Please try again.
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-orbitron font-bold text-cyber-teal">LOOP LIBRARY</h1>
          <Button 
            onClick={() => setLocation('/')}
            className="cyber-button px-4 py-2 text-cyber-electric hover:text-white rounded"
          >
            ← BACK
          </Button>
        </div>

        {/* Loop Library Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loops?.map((loop) => (
            <Card key={loop.id} className="track-label border-cyber-teal/30 bg-cyber-navy/20">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-orbitron text-cyber-teal">{loop.name}</span>
                  <span className="text-xs text-cyber-electric px-2 py-1 bg-cyber-navy rounded">
                    {loop.bpm} BPM
                  </span>
                </div>
                {loop.mood && (
                  <div className="text-sm text-gray-400 mb-3">{loop.mood}</div>
                )}
                <Button 
                  onClick={() => handleDownload(loop)}
                  className="cyber-button w-full py-2 text-cyber-teal hover:text-white rounded text-sm"
                >
                  DOWNLOAD
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {(!loops || loops.length === 0) && (
          <div className="text-center py-12">
            <div className="text-cyber-electric font-orbitron text-xl mb-4">
              No loops available
            </div>
            <p className="text-gray-400">
              Audio assets will be available once they are uploaded to the server.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
