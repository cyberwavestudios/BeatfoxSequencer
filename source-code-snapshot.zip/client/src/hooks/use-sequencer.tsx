import { useState, useEffect, useCallback } from 'react';
import { audioEngine } from '@/lib/audio-engine';
import { defaultTracks, type TrackConfig } from '@shared/schema';

export function useSequencer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [bpm, setBpm] = useState(90);
  const [tracks, setTracks] = useState<TrackConfig[]>(defaultTracks);
  const [selectedLoop, setSelectedLoop] = useState<string>('');
  const [selectedLoopData, setSelectedLoopData] = useState<any>(null);
  const [autoSync] = useState(true); // Always enabled
  const [isInitialized, setIsInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Initialize audio engine and load default loop
  useEffect(() => {
    const initAudio = async () => {
      await audioEngine.initialize();
      
      // Load default tracks
      for (const track of defaultTracks) {
        const audioUrl = track.filename 
          ? `/audio/samples/${track.filename}`
          : undefined;
          
        try {
          await audioEngine.loadTrack({
            id: track.id,
            name: track.name,
            type: track.type,
            audioUrl,
            hasPitchControl: track.hasPitchControl,
          });
          
          // Set default pitch if specified in track config
          if (track.pitch !== undefined && track.pitch !== 0) {
            audioEngine.setTrackPitch(track.id, track.pitch);
            console.log(`Set default pitch for ${track.id}: ${track.pitch}`);
          }
        } catch (error) {
          console.warn(`Failed to load track ${track.name}:`, error);
          // Continue loading other tracks even if one fails
        }
      }

      // Setup sequence with step callback
      audioEngine.setupSequence((step) => {
        setCurrentStep(step);
      });

      // Auto-load first loop by default
      try {
        const defaultLoopData = { name: "Hyperblues Guitar", filename: "150_Hyperblues_Guitar_Fm.wav", bpm: 150, key: "Fm" };
        await loadLoop(defaultLoopData.filename, defaultLoopData);
      } catch (error) {
        console.warn('Failed to load default loop:', error);
      }

      setIsInitialized(true);
    };

    initAudio();

    return () => {
      audioEngine.dispose();
    };
  }, []);

  const play = useCallback(async () => {
    if (!isInitialized) return;
    
    try {
      // Start audio context if needed (user gesture required)
      await audioEngine.initialize();
      await audioEngine.play();
      setIsPlaying(true);
    } catch (error) {
      console.error('Failed to start playback:', error);
    }
  }, [isInitialized]);

  const pause = useCallback(() => {
    try {
      audioEngine.pause();
      setIsPlaying(false);
    } catch (error) {
      console.error('Failed to pause playback:', error);
    }
  }, []);

  const stop = useCallback(() => {
    try {
      audioEngine.stop();
      setIsPlaying(false);
      setCurrentStep(0);
    } catch (error) {
      console.error('Failed to stop playback:', error);
    }
  }, []);

  // BPM is auto-synced from loops only - no manual control

  const toggleStep = useCallback((trackId: string, stepIndex: number) => {
    audioEngine.toggleStep(trackId, stepIndex);
    
    setTracks(prev => prev.map(track => {
      if (track.id === trackId) {
        const newSteps = [...track.steps];
        newSteps[stepIndex] = !newSteps[stepIndex];
        return { ...track, steps: newSteps };
      }
      return track;
    }));
  }, []);

  const setTrackPitch = useCallback((trackId: string, pitch: number) => {
    audioEngine.setTrackPitch(trackId, pitch);
    
    setTracks(prev => prev.map(track => {
      if (track.id === trackId) {
        return { ...track, pitch };
      }
      return track;
    }));
  }, []);

  const loadLoop = useCallback(async (loopFilename: string, loopData?: any) => {
    // Show loading animation until completion
    setIsLoading(true);
    
    try {
      // Always force complete stop before loading new loop
      audioEngine.stop();
      setIsPlaying(false);
      setCurrentStep(0);
      
      // Minimal delay for clean stop
      await new Promise(resolve => setTimeout(resolve, 50));
      
      const audioUrl = `/audio/loops/${loopFilename}`;
      
      // Load new loop into the audio engine with error handling
      await audioEngine.loadTrack({
        id: 'loop',
        name: 'LOOP',
        type: 'loop',
        audioUrl: audioUrl,
        hasPitchControl: true,
      });

      setSelectedLoop(loopFilename);
      setSelectedLoopData(loopData);

      // Always auto-sync project BPM and key to loop
      if (loopData?.bpm) {
        setBpm(loopData.bpm);
        audioEngine.setBPM(loopData.bpm);
        console.log('Auto-synced BPM to:', loopData.bpm);
      }
      
      // Update the loop track in the tracks state to show it's loaded
      setTracks(prev => prev.map(track => {
        if (track.id === 'loop') {
          return { 
            ...track, 
            name: loopData?.name || 'LOOP',
            steps: new Array(8).fill(true) // Show as active
          };
        }
        return track;
      }));
      
      console.log('Loop loaded successfully:', loopFilename);
      
      // Hide loading animation after successful completion
      setIsLoading(false);
    } catch (error) {
      console.error('Failed to load loop:', loopFilename, error);
      setIsLoading(false); // Hide loading animation on error too
      throw error; // Re-throw so UI can handle it
    }
  }, []);

  const exportSequence = useCallback(async () => {
    try {
      const blob = await audioEngine.exportSequence();
      
      // Create download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `beatfox-sequence-${selectedLoopData?.name || 'export'}.wav`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      return true;
    } catch (error) {
      console.error('Export failed:', error);
      return false;
    }
  }, [selectedLoopData]);

  return {
    isPlaying,
    currentStep,
    bpm,
    tracks,
    selectedLoop,
    isInitialized,
    play,
    pause,
    stop,
    toggleStep,
    setTrackPitch,
    loadLoop,
    exportSequence,
    progress: (currentStep + 1) / 8,
    selectedLoopData,
    hasSelectedLoop: !!selectedLoop,
    isLoading,
  };
}
