import { useState, useEffect, useCallback, useRef } from 'react';

type OrientationType = 'portrait' | 'landscape';

export function useDeviceOrientation() {
  const [orientation, setOrientation] = useState<OrientationType>(() => {
    if (typeof window === 'undefined') return 'portrait';
    return detectOrientation();
  });
  const gyroCleanupRef = useRef<(() => void) | null>(null);
  const gyroInitializedRef = useRef(false);

  const handleOrientationChange = useCallback(() => {
    setOrientation(detectOrientation());
  }, []);

  useEffect(() => {
    window.addEventListener('orientationchange', handleOrientationChange);
    window.addEventListener('resize', handleOrientationChange);

    const mql = window.matchMedia('(orientation: landscape)');
    if (mql.addEventListener) {
      mql.addEventListener('change', handleOrientationChange);
    }

    if ('DeviceOrientationEvent' in window) {
      const requestPermission = (DeviceOrientationEvent as any).requestPermission;
      if (typeof requestPermission !== 'function') {
        gyroCleanupRef.current = setupGyroscope(setOrientation);
        gyroInitializedRef.current = true;
      }
    }

    return () => {
      window.removeEventListener('orientationchange', handleOrientationChange);
      window.removeEventListener('resize', handleOrientationChange);
      if (mql.removeEventListener) {
        mql.removeEventListener('change', handleOrientationChange);
      }
      if (gyroCleanupRef.current) gyroCleanupRef.current();
    };
  }, [handleOrientationChange]);

  useEffect(() => {
    if (gyroInitializedRef.current) return;

    const requestPermission = (DeviceOrientationEvent as any)?.requestPermission;
    if (typeof requestPermission !== 'function') return;

    const requestGyroPermission = () => {
      requestPermission().then((permission: string) => {
        if (permission === 'granted') {
          gyroCleanupRef.current = setupGyroscope(setOrientation);
          gyroInitializedRef.current = true;
        }
      }).catch(() => {});
      document.removeEventListener('touchstart', requestGyroPermission);
      document.removeEventListener('click', requestGyroPermission);
    };

    document.addEventListener('touchstart', requestGyroPermission, { once: true });
    document.addEventListener('click', requestGyroPermission, { once: true });

    return () => {
      document.removeEventListener('touchstart', requestGyroPermission);
      document.removeEventListener('click', requestGyroPermission);
    };
  }, []);

  return orientation;
}

function detectOrientation(): OrientationType {
  if (typeof window === 'undefined') return 'portrait';

  if (screen.orientation?.type) {
    return screen.orientation.type.startsWith('landscape') ? 'landscape' : 'portrait';
  }

  const wo = (window as any).orientation;
  if (typeof wo === 'number') {
    return (wo === 90 || wo === -90) ? 'landscape' : 'portrait';
  }

  if (window.matchMedia('(orientation: landscape)').matches) {
    return 'landscape';
  }

  return window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
}

function setupGyroscope(setOrientation: (o: OrientationType) => void): () => void {
  let lastOrientation: OrientationType | null = null;

  const handler = (event: DeviceOrientationEvent) => {
    const gamma = event.gamma;
    if (gamma === null) return;

    const detected: OrientationType = Math.abs(gamma) > 45 ? 'landscape' : 'portrait';

    if (detected !== lastOrientation) {
      lastOrientation = detected;
      setOrientation(detected);
    }
  };

  window.addEventListener('deviceorientation', handler);
  return () => window.removeEventListener('deviceorientation', handler);
}
