import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const loops = pgTable("loops", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  filename: text("filename").notNull(),
  bpm: integer("bpm").notNull().default(90),
  key: text("key"), // Musical key (e.g., "Am", "F#m", "C")
  mood: text("mood"),
  duration: integer("duration"), // in milliseconds
});

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().default("Untitled Project"),
  bpm: integer("bpm").notNull().default(90),
  tracks: jsonb("tracks").notNull().default({}), // stores step sequences and settings
  selectedLoop: text("selected_loop"),
  loopPitch: integer("loop_pitch").default(0),
});

export const insertLoopSchema = createInsertSchema(loops).omit({
  id: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
});

export type Loop = typeof loops.$inferSelect;
export type InsertLoop = z.infer<typeof insertLoopSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

// Track configuration for the sequencer
export interface TrackConfig {
  id: string;
  name: string;
  type: 'loop' | 'oneshot';
  color: string;
  filename?: string;
  hasPitchControl?: boolean;
  pitch?: number; // ±12 semitones
  steps: boolean[]; // 8 step sequence
  muted?: boolean;
  volume?: number;
}

export const defaultTracks: TrackConfig[] = [
  { id: 'loop', name: 'LOOP', type: 'loop', color: '#00ffff', hasPitchControl: true, pitch: 0, steps: new Array(8).fill(false) },
  { id: 'hihat', name: 'HI-HAT', type: 'oneshot', color: '#40e0d0', filename: 'hihat.wav', steps: new Array(8).fill(false) },
  { id: 'clap', name: 'CLAP', type: 'oneshot', color: '#ff6b6b', filename: 'clap.wav', steps: new Array(8).fill(false) },
  { id: 'perc1', name: 'PERC 1', type: 'oneshot', color: '#00ff41', filename: 'perc1.wav', steps: new Array(8).fill(false) },
  { id: 'perc2', name: 'PERC 2', type: 'oneshot', color: '#ff4500', filename: 'perc2.wav', hasPitchControl: true, pitch: 0, steps: new Array(8).fill(false) },
  { id: 'cyber808', name: 'CYBER 808', type: 'oneshot', color: '#9400d3', filename: 'cyber808.wav', hasPitchControl: true, pitch: 0, steps: new Array(8).fill(false) },
  { id: 'crash', name: 'CRASH CYMBAL', type: 'oneshot', color: '#ffd700', filename: 'crash.wav', steps: new Array(8).fill(false) },
  { id: 'china', name: 'CHINA CYMBAL', type: 'oneshot', color: '#ff69b4', filename: 'china.wav', steps: new Array(8).fill(false) },
  { id: 'bass1', name: 'BASS 1', type: 'oneshot', color: '#ffff00', filename: 'bass1.wav', hasPitchControl: true, pitch: 0, steps: new Array(8).fill(false) },
  { id: 'bass2', name: 'BASS 2', type: 'oneshot', color: '#ffa500', filename: 'bass2.wav', hasPitchControl: true, pitch: -2, steps: new Array(8).fill(false) },
  { id: 'bass3', name: 'BASS 3', type: 'oneshot', color: '#ff1493', filename: 'bass3.wav', hasPitchControl: true, pitch: 0, steps: new Array(8).fill(false) },
  { id: 'bass4', name: 'BASS 4', type: 'oneshot', color: '#00ced1', filename: 'bass4.wav', hasPitchControl: true, pitch: 0, steps: new Array(8).fill(false) },
  { id: 'snare', name: 'SNARE', type: 'oneshot', color: '#8b5cf6', filename: 'snare.wav', steps: new Array(8).fill(false) },
  { id: 'kick', name: 'KICK', type: 'oneshot', color: '#ff006e', filename: 'kick.wav', steps: new Array(8).fill(false) },
];
