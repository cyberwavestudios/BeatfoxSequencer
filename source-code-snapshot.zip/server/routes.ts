import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import path from "path";
import { fileURLToPath } from "url";
import express from "express";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Serve static audio files
  app.use('/audio', express.static(path.join(__dirname, '../public/audio')));
  
  // Get all available loops
  app.get("/api/loops", async (_req, res) => {
    try {
      const loops = await storage.getLoops();
      res.json(loops);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch loops" });
    }
  });

  // Get loop by ID
  app.get("/api/loops/:id", async (req, res) => {
    try {
      const loop = await storage.getLoop(req.params.id);
      if (!loop) {
        return res.status(404).json({ message: "Loop not found" });
      }
      res.json(loop);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch loop" });
    }
  });

  // Download loop file
  app.get("/api/loops/:id/download", async (req, res) => {
    try {
      const loop = await storage.getLoop(req.params.id);
      if (!loop) {
        return res.status(404).json({ message: "Loop not found" });
      }
      
      const filePath = path.join(__dirname, '../public/audio/loops', loop.filename);
      res.download(filePath, loop.filename);
    } catch (error) {
      res.status(500).json({ message: "Failed to download loop" });
    }
  });

  // Create project
  app.post("/api/projects", async (req, res) => {
    try {
      const project = await storage.createProject(req.body);
      res.status(201).json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Get project by ID
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  // Update project
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.updateProject(req.params.id, req.body);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
