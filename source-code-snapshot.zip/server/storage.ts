import { type Loop, type InsertLoop, type Project, type InsertProject } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Loops
  getLoops(): Promise<Loop[]>;
  getLoop(id: string): Promise<Loop | undefined>;
  createLoop(loop: InsertLoop): Promise<Loop>;
  
  // Projects
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<Project>): Promise<Project | undefined>;
}

export class MemStorage implements IStorage {
  private loops: Map<string, Loop>;
  private projects: Map<string, Project>;

  constructor() {
    this.loops = new Map();
    this.projects = new Map();
    
    // Initialize with some default loops
    this.initializeDefaultLoops();
  }

  private async initializeDefaultLoops() {
    const defaultLoops: InsertLoop[] = [
      {
        name: "Hyperblues Guitar",
        filename: "150_Hyperblues_Guitar_Fm.wav",
        bpm: 150,
        key: "Fm",
        mood: "Synthwave Guitar",
        duration: 8000,
      },
      {
        name: "StarSynth",
        filename: "150_StarSynth_A#m.wav",
        bpm: 150,
        key: "A#m",
        mood: "Ethereal Synthwave",
        duration: 8000,
      },
      {
        name: "EDM Synth",
        filename: "171_EDM_Synth_G#m.wav",
        bpm: 171,
        key: "G#m",
        mood: "High Energy EDM",
        duration: 8000,
      },


      {
        name: "Pop Songstarter",
        filename: "170_Pop_Songstarter_Fm.wav",
        bpm: 170,
        key: "Fm",
        mood: "Modern Pop",
        duration: 8000,
      },
      {
        name: "Hyperpop Guitar Progression",
        filename: "160_Hyperpop_Guitar_Progression_C#m.wav",
        bpm: 160,
        key: "C#m",
        mood: "Progressive Hyperpop",
        duration: 8000,
      },
      {
        name: "Airy Synth Leads",
        filename: "150_Airy_Synth_Leads_Em.wav",
        bpm: 150,
        key: "Em",
        mood: "Dreamy Synthwave",
        duration: 8000,
      },
      {
        name: "Dystopia Synths",
        filename: "140_DystopiaSynths_Em.wav",
        bpm: 140,
        key: "Em",
        mood: "Dark Cyberpunk",
        duration: 8000,
      },
      {
        name: "Cyber Keys",
        filename: "155_CyberKeys_Am.wav",
        bpm: 155,
        key: "Am",
        mood: "Retro Cyber",
        duration: 8000,
      },
      {
        name: "Acoustic Feelz",
        filename: "135_AcousticFeelz_Am.wav",
        bpm: 135,
        key: "Am",
        mood: "Organic Texture",
        duration: 8000,
      },
      {
        name: "I Might Be John Mayer IDK",
        filename: "134_IMightBeJohnMayerIDK_F#m.wav",
        bpm: 134,
        key: "F#m",
        mood: "Smooth Guitar",
        duration: 8000,
      },
      {
        name: "Cyber Reese Loop",
        filename: "139_Cyber_Reese_Loop_Dm.wav",
        bpm: 139,
        key: "Dm",
        mood: "Deep Bass Synth",
        duration: 8000,
      },
      {
        name: "Digital Lead",
        filename: "160_Digital_Lead_Bm.wav",
        bpm: 160,
        key: "Bm",
        mood: "Crisp Digital",
        duration: 8000,
      },
    ];

    for (const loop of defaultLoops) {
      await this.createLoop(loop);
    }
  }

  async getLoops(): Promise<Loop[]> {
    return Array.from(this.loops.values());
  }

  async getLoop(id: string): Promise<Loop | undefined> {
    return this.loops.get(id);
  }

  async createLoop(insertLoop: InsertLoop): Promise<Loop> {
    const id = randomUUID();
    const loop: Loop = { 
      ...insertLoop, 
      id,
      bpm: insertLoop.bpm ?? 120,
      key: insertLoop.key ?? null,
      duration: insertLoop.duration ?? null,
      mood: insertLoop.mood ?? null
    };
    this.loops.set(id, loop);
    return loop;
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = { 
      ...insertProject, 
      id,
      name: insertProject.name ?? "Untitled Project",
      bpm: insertProject.bpm ?? 90,
      tracks: insertProject.tracks ?? {},
      selectedLoop: insertProject.selectedLoop ?? null,
      loopPitch: insertProject.loopPitch ?? null
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: string, projectUpdate: Partial<Project>): Promise<Project | undefined> {
    const existingProject = this.projects.get(id);
    if (!existingProject) return undefined;
    
    const updatedProject = { ...existingProject, ...projectUpdate };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
}

export const storage = new MemStorage();
